/**
 * Created by Administrator on 2018/11/20.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        $('.payment_open_vip_head .open_vip_head_not').on('click',function () {
            $('.open_vip_head_yes').show();
            $('.open_vip_head_not').hide();
            $('.payment_open_vip_bottom').show();
            $('.single_head_yes').hide();
            $('.single_head_not').show();
            $('.payment_info_single').attr('data_single',0);
            $('.payment_open_vip').attr('data_open',1);
            $('.payment_btns .payment_buy_info').hide();
            $('.payment_btns .payment_open_info').show();
        });
        $('.payment_info_single_head .single_head_not').on('click',function () {
            $('.open_vip_head_yes').hide();
            $('.open_vip_head_not').show();
            $('.payment_open_vip_bottom').hide();
            $('.single_head_yes').show();
            $('.single_head_not').hide();
            $('.payment_info_single').attr('data_single',1);
            $('.payment_open_vip').attr('data_open',0);
            $('.payment_btns .payment_buy_info').show();
            $('.payment_btns .payment_open_info').hide();
        });
    })
});