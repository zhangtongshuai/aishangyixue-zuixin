/**
 * Created by Administrator on 2018/11/15.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        //横向滑动导航
        var oBox = $('.box');
        var oBoxWidth = $('.box').width();
        oBox.find('div').on('click',function(){
            var thisWidth = $(this).width();
            var moveLeft = this.offsetLeft;
            if(oBoxWidth<moveLeft+thisWidth){
                oBox.animate({scrollLeft:moveLeft});
            }else{
                oBox.animate({scrollLeft:0});
            }
        });
        $('.classify_info .concent div p').on('click',function () {
            $(this).parents('.box').find('div').find('p').removeClass('active')
            $(this).addClass('active');
        })


    })
});