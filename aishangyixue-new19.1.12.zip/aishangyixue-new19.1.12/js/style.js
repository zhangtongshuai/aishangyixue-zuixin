/**
 * Created by Administrator on 2018/11/13.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata'],function ($,wui,validata) {
        $('.courses_list_info li .courses_img img').height($('.courses_list_info li .courses_img img').width()*0.85);
        var btn_height = $('.courses_list .courses_list_info li .courses_right button').height()/2;
        $('.courses_list .courses_list_info li .courses_right button').css('border-radius',btn_height + 'px')
    })
});
