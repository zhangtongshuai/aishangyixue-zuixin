/**
 * Created by Administrator on 2018/11/13.
 */
requirejs.config({
    paths:{
        jquery:'jquery.min',
        jqueryweui:'jquery-weui.min',
        swiper:'swiper.min',
        style:'style',
        md5:'md5'
    },
    shim: {
        "style":{
            deps: ['jquery']
        },
        "jqueryweui":{
            deps: ['jquery']
        },
        "swiper":{
            deps: ['jquery']
        },
        "md5":{
            deps: ['jquery']
        }
    }
});