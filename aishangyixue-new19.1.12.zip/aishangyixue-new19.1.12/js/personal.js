/**
 * Created by Administrator on 2018/11/16.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        $('.personal_head_left img').height($('.personal_head_left img').width());
        var bwidth = $('.personal_head_right b').width();
        $('.personal_head_right b').height(bwidth);
        $('.personal_head_right b').css('line-height',bwidth +'px')

    })
});