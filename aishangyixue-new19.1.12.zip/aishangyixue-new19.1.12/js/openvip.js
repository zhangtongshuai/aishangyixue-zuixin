/**
 * Created by Administrator on 2018/11/21.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        $('.openvip_center .openvip_list').on('click',function () {
            var index = $(this).index();
            $(this).addClass('active').siblings().removeClass('active');
            $('.openvip_center').attr('data_open',index);
        });

    })
});