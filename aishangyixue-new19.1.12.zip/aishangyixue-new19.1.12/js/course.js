/**
 * Created by Administrator on 2018/11/19.
 */
requirejs(['common'],function(c){
    requirejs(['jquery','jqueryweui','validata','style'],function ($,wui,validata,style) {
        var isEqual = validata.isEqual(1,2);
        console.log(isEqual);
        $('.course_details_nav ul li').on('click',function () {
            var index = $(this).index();
            $(this).addClass('active').siblings().removeClass('active');
            $('.course_details_info').find('.course_details_list').eq(index).show().siblings().hide();
        });
        $('.course_details_image_text .view_button button').on('click',function () {
            $('.tips_shade').show();
        });
        $('.tips_shade_bj').on('click',function () {
            $('.audio_tips_shade').hide();
            $('.tips_shade').hide();
        });
        //旋转音频
        var audio = document.getElementById("audio");
        audio.pause();
        var t1;
        var t2;
        var audio_length;
        if(audio.currentSrc != ''){
            audio.load();
            audio.oncanplay = function () {
                audio_length = validata.formatTime(audio.duration);
                if(audio_length !=''){
                    $('.progress_point').find('i').html(audio_length);
                }else{
                    $('.progress_point').find('i').html('00:00');
                }
            };
        }else{
            $('.progress_point').find('i').html('00:00');
        }
        var bar_proportion_new = '';
        function refreshCount() {
            var audio_play_time = validata.formatTime(audio.currentTime);
            $('.progress_point').find('span').html(audio_play_time);
            var now_time = parseInt(audio.currentTime);
            var all_time = parseInt(audio.duration);
            var line_width = (now_time/all_time)*100;
            var line_width1 = Math.floor(line_width);
            var audio_total_width = $('.progress_bar').width();
            var audio_point_width = $('.progress_point').width();
            var audio_bar_new_width = audio_total_width - audio_point_width;
            var bar_proportion = audio_bar_new_width/audio_total_width;
            if(bar_proportion_new == ''){
                bar_proportion_new = Math.floor(bar_proportion*100);
            }
            var line_width2=line_width1*bar_proportion_new/100;
            $('.audio_info_bottom_center .progress_bar_new').css('width',line_width2+'%');
            if(line_width2> bar_proportion_new){
                $('.audio_info_bottom_center .progress_point').css('left',bar_proportion_new+'%');
            }else{
                $('.audio_info_bottom_center .progress_point').css('left',line_width2+'%');
            }
            if(audio.currentTime == audio.duration){
                audio.pause();
                $('.img_play').show();
                $('.img_stop').hide();
                $('.audio_info_head_img').removeClass('revolve');
                clearInterval(t1);
            }
        }
        $('.audio_info_head .img_play').on('click',function () {
            $('.audio_tips_shade').show();
            if(audio.paused){
                audio.play();
                $('.img_play').hide();
                $('.img_stop').show();
                $('.audio_info_head_img').addClass('revolve');
                if(audio.currentTime == audio.duration){
                    audio.currentTime = '0';
                    $('.audio_info_bottom_center .progress_point').css('left','0%');
                    $('.audio_info_bottom_center .progress_bar_new').css('width','0%');
                }
                t1=setInterval(refreshCount, 1000);
            }
        });
        $('.audio_info_head .img_stop').on('click',function () {
            if(!audio.paused){
                clearInterval(t1);
                audio.pause();
                $('.img_play').show();
                $('.img_stop').hide();
                $('.audio_info_head_img').removeClass('revolve');
            }
        });
        $('.audio_info_bottom_left').on('click',function () {
            clearInterval(t1);
            var play_time = parseInt(audio.currentTime);
            if(play_time <= 15){
                audio.currentTime = '0';
                $('.audio_info_bottom_center .progress_point').css('left','0%');
                $('.audio_info_bottom_center .progress_bar_new').css('width','0%');
            }else{
                var now_time = play_time-15;
                var all_time = parseInt(audio.duration);
                audio.currentTime = now_time;
                var line_width = (now_time/all_time)*100;
                var line_width1 = Math.floor(line_width);
                var line_width2=line_width1*bar_proportion_new/100;
                $('.audio_info_bottom_center .progress_bar_new').css('width',line_width2+'%');
                if(line_width2>bar_proportion_new){
                    $('.audio_info_bottom_center .progress_point').css('left',bar_proportion_new+'%');
                }else{
                    $('.audio_info_bottom_center .progress_point').css('left',line_width2+'%');
                }
            }
            t1=setInterval(refreshCount, 1000);
        });
        $('.audio_info_bottom_right').on('click',function () {
            clearInterval(t1);
            var all_time = parseInt(audio.duration);
            var play_time = parseInt(audio.currentTime);
            if((all_time - play_time)<=15){
                audio.currentTime = all_time;
                $('.audio_info_bottom_center .progress_point').css('left',bar_proportion_new+'%');
                $('.audio_info_bottom_center .progress_bar_new').css('width','100%');
            }else{
                var now_time;
                now_time = play_time+15;
                if(now_time>all_time){
                    now_time = all_time;
                }
                audio.currentTime = now_time;
                var line_width = (now_time/all_time)*100;
                var line_width1 = Math.floor(line_width);
                var line_width2=line_width1*bar_proportion_new/100;
                $('.audio_info_bottom_center .progress_bar_new').css('width',line_width2+'%');
                if(line_width2>bar_proportion_new){
                    $('.audio_info_bottom_center .progress_point').css('left',bar_proportion_new+'%');
                }else{
                    $('.audio_info_bottom_center .progress_point').css('left',line_width2+'%');
                }
            }
            t1=setInterval(refreshCount, 1000);
        });

        //视频播放
        var video = document.getElementById("video");
        video.pause();
        function refreshCount1() {
            var video_play_time = validata.formatTime(video.currentTime);
            $('.handle_info_top').find('.video_ptime').html(video_play_time);
            var now_time = parseInt(video.currentTime);
            var all_time = parseInt(video.duration);
            var line_width = (now_time/all_time)*100;
            var line_width1 = Math.floor(line_width);
            $('.handle_left_bottom .handle_left_bottom_new').css('width',line_width1+'%');
            var line_width2 = line_width1-1;
            $('.handle_left_bottom img').css('left',line_width2+'%');
            if(video.currentTime == video.duration){
                video.pause();
                $('.state_btns .play_btn').show();
                $('.state_btns .stop_btn').hide();
                $('.video_info .handle_info').show();
                clearInterval(t2);
                exitFullscreen();
            }
        }
        var video_length = validata.formatTime(video.duration);
        if(video.currentSrc == ''){
            $('.handle_info .handle_info_top').find('.video_len').html('00:00');
        }else{
            if(video_length == 'NaN:NaN'){
                $('.handle_info .handle_info_top').find('.video_len').html('00:00');
            }else{
                $('.handle_info .handle_info_top').find('.video_len').html(video_length);
            }
        }
        $('.state_btns .play_btn').on('click',function () {
            $('.audio_tips_shade').show();
            if(video.paused){
                video.play();
                // $('.state_btns .play_btn').hide();
                // $('.state_btns .stop_btn').show();
                // if(video.currentTime == video.duration){
                //     video.currentTime = '0';
                //     $('.handle_left_bottom img').css('left','0%');
                //     $('.handle_left_bottom .handle_left_bottom_new').css('width','0%');
                // }
                // t2=setInterval(refreshCount1, 1000);
                // $('.state_btns .stop_btn').fadeOut(500);
                // $('.video_info .handle_info').fadeOut(500);
            }
        });
        $('#video').on('click',function () {
            if(!video.paused){
                clearInterval(t2);
                video.pause();
                $('.state_btns .stop_btn').hide();
                $('.state_btns .play_btn').fadeIn(500);
                $('.video_info .handle_info').fadeIn(500);
            }
        });
        $('.state_btns .stop_btn').on('click',function () {
            if(!video.paused){
                clearInterval(t2);
                video.pause();
                $('.state_btns .play_btn').show();
                $('.state_btns .stop_btn').hide();
            }
        });
        $('.time_btn_retreat').on('click',function () {
            clearInterval(t2);
            var play_time = parseInt(video.currentTime);
            if(play_time <= 15){
                video.currentTime = '0';
                $('.handle_left_bottom img').css('left','-1%');
                $('.handle_left_bottom .handle_left_bottom_new').css('width','0%');
                t2=setInterval(refreshCount1, 1000);
            }else{
                var now_time = play_time-15;
                var all_time = parseInt(video.duration);
                video.currentTime = now_time;
                var line_width = (now_time/all_time)*100;
                var line_width1 = Math.floor(line_width);
                $('.handle_left_bottom .handle_left_bottom_new').css('width',line_width1+'%');
                var line_width2 = line_width1-1;
                $('.handle_left_bottom img').css('left',line_width2+'%');
                t2=setInterval(refreshCount1, 1000);
            }
        });
        $('.time_btn_forward').on('click',function () {
            clearInterval(t2);
            var all_time = parseInt(video.duration);
            var play_time = parseInt(video.currentTime);
            console.log(play_time);
            if((all_time - play_time)<=15){
                video.currentTime = all_time;
                $('.handle_left_bottom img').css('left','99%');
                $('.handle_left_bottom .handle_left_bottom_new').css('width','100%');
            }else{
                var now_time;
                    now_time = play_time+15;
                if(now_time>all_time){
                    now_time = all_time;
                }
                video.currentTime = now_time;
                var line_width = (now_time/all_time)*100;
                var line_width1 = Math.floor(line_width);
                $('.handle_left_bottom .handle_left_bottom_new').css('width',line_width1+'%');
                var line_width2 = line_width1-1;
                $('.handle_left_bottom img').css('left',line_width2+'%');
            }
            t2=setInterval(refreshCount1, 1000);
        });
        //进入全屏
        var u = navigator.userAgent;
        var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
        $('.handle_info_right .enlarge_btn').on('click',function () {
            var ele = document.getElementById('video_info_id');
            if (isAndroid) {
                ele.style.width = window.width + 'px';
                ele.style.height = window.height + 'px';
            }
            if (ele .requestFullscreen) {
                ele .requestFullscreen();
            } else if (ele .mozRequestFullScreen) {
                ele .mozRequestFullScreen();
            } else if (ele .webkitRequestFullScreen) {
                ele .webkitRequestFullScreen();
            } else if (ele.msRequestFullscreen) {
                ele.msRequestFullscreen();
            }
            $('.handle_info_right .enlarge_btn').hide();
            $('.handle_info_right .deflate_btn').show();
        });
        //退出全屏
        function exitFullscreen() {
            var de = document;
            if (de.exitFullscreen) {
                de.exitFullscreen();
            } else if (de.mozCancelFullScreen) {
                de.mozCancelFullScreen();
            } else if (de.webkitCancelFullScreen) {
                de.webkitCancelFullScreen();
            }else if (de.msExitFullscreen) {
                de.msExitFullscreen();
            }
            $('.handle_info_right .enlarge_btn').show();
            $('.handle_info_right .deflate_btn').hide();
        }
        $('.handle_info_right .deflate_btn').on('click',function () {
            exitFullscreen();
        });
        $('.course_details_nav ul li').eq(0).on('click',function () {
            $('.audio_recommend').hide();
            if(!audio.paused){
                clearInterval(t1);
                audio.pause();
                $('.img_play').show();
                $('.img_stop').hide();
                $('.audio_info_head_img').removeClass('revolve');
            }
            if(!video.paused){
                clearInterval(t2);
                video.pause();
                $('.state_btns .play_btn').show();
                $('.state_btns .stop_btn').hide();
            }
        });
        $('.course_details_nav ul li').eq(1).on('click',function () {
            $('.audio_recommend').show();
            if(!video.paused){
                clearInterval(t2);
                video.pause();
                $('.state_btns .play_btn').show();
                $('.state_btns .stop_btn').hide();
            }
        });
        $('.course_details_nav ul li').eq(2).on('click',function () {
            $('.audio_recommend').show();
            if(!audio.paused){
                clearInterval(t1);
                audio.pause();
                $('.img_play').show();
                $('.img_stop').hide();
                $('.audio_info_head_img').removeClass('revolve');
            }
        });
    });
});